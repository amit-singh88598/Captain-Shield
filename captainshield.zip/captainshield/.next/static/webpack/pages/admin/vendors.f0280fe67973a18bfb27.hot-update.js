webpackHotUpdate_N_E("pages/admin/vendors",{

/***/ "./Components/admin/vendorList.js":
/*!****************************************!*\
  !*** ./Components/admin/vendorList.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return GenerateCode; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var D_KIB_captainshield_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/styles */ "./node_modules/@material-ui/core/esm/styles/index.js");
/* harmony import */ var _material_ui_core_Slide__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Slide */ "./node_modules/@material-ui/core/esm/Slide/index.js");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _actions_vendor__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../actions/vendor */ "./actions/vendor.js");
/* harmony import */ var _actions_vendor__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_actions_vendor__WEBPACK_IMPORTED_MODULE_7__);




var _jsxFileName = "D:\\KIB\\captainshield\\Components\\admin\\vendorList.js",
    _s = $RefreshSig$();






var useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__["makeStyles"])(function (theme) {
  return {
    root: {
      paddingBottom: 20,
      paddingRight: 20,
      backgroundColor: theme.palette.primary.main
    },
    cardStyle: {
      borderRadius: 20,
      padding: 40,
      backgroundColor: theme.palette.secondary.light,
      height: 675
    },
    details: {
      marginLeft: 10,
      color: theme.palette.primary.light
    },
    heading: {
      fontSize: "1.5em",
      display: "flex",
      justifyContent: "center",
      color: theme.palette.primary.light
    },
    expand: {
      transform: "rotate(0deg)",
      marginLeft: "auto",
      marginRight: 10,
      backgroundColor: theme.palette.secondary.main,
      color: theme.palette.primary.light
    },
    totalCodes: {
      display: "flex",
      justifyContent: "center",
      borderStyle: "outset ",
      borderRadius: 15,
      borderTop: 0,
      borderLeft: 0,
      padding: 5,
      height: 600,
      margin: 20,
      backgroundColor: theme.palette.secondary.main
    }
  };
});
function GenerateCode() {
  _s();

  var _this = this;

  var classes = useStyles();

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(null),
      profile = _useState[0],
      setProfile = _useState[1];

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])( /*#__PURE__*/Object(D_KIB_captainshield_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee() {
    return D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return Object(_actions_vendor__WEBPACK_IMPORTED_MODULE_7__["getVendors"])(function (error, result) {
              if (error) {
                console.log(error);
              } else {
                setProfile(result.data);
              }
            });

          case 2:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  })), []);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: classes.root,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Card"], {
      className: classes.cardStyle,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Card"], {
        className: classes.totalCodes,
        elevation: 2,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["CardContent"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
            className: classes.heading,
            variant: "h1",
            children: "Vendors"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 76,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 75,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["CardActions"], {
          disableSpacing: true,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
            className: classes.details,
            variant: "h6",
            children: "Name"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 81,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
            className: classes.expand,
            variant: "h6",
            children: "Codes"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 84,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 80,
          columnNumber: 11
        }, this), profile && profile.map(function (item, index) {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["CardActions"], {
            disableSpacing: true,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
              className: classes.details,
              "aria-label": "show more",
              variant: "subtitle1",
              children: item.primaryNumber
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 91,
              columnNumber: 17
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
              className: classes.expand,
              variant: "subtitle1",
              children: item.keys.length
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 98,
              columnNumber: 17
            }, _this)]
          }, index, true, {
            fileName: _jsxFileName,
            lineNumber: 90,
            columnNumber: 15
          }, _this);
        })]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 70,
    columnNumber: 5
  }, this);
}

_s(GenerateCode, "MxkcOQ8VgTzKXCFgD7ayA1lKrDU=", false, function () {
  return [useStyles];
});

_c = GenerateCode;

var _c;

$RefreshReg$(_c, "GenerateCode");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vQ29tcG9uZW50cy9hZG1pbi92ZW5kb3JMaXN0LmpzIl0sIm5hbWVzIjpbInVzZVN0eWxlcyIsIm1ha2VTdHlsZXMiLCJ0aGVtZSIsInJvb3QiLCJwYWRkaW5nQm90dG9tIiwicGFkZGluZ1JpZ2h0IiwiYmFja2dyb3VuZENvbG9yIiwicGFsZXR0ZSIsInByaW1hcnkiLCJtYWluIiwiY2FyZFN0eWxlIiwiYm9yZGVyUmFkaXVzIiwicGFkZGluZyIsInNlY29uZGFyeSIsImxpZ2h0IiwiaGVpZ2h0IiwiZGV0YWlscyIsIm1hcmdpbkxlZnQiLCJjb2xvciIsImhlYWRpbmciLCJmb250U2l6ZSIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsImV4cGFuZCIsInRyYW5zZm9ybSIsIm1hcmdpblJpZ2h0IiwidG90YWxDb2RlcyIsImJvcmRlclN0eWxlIiwiYm9yZGVyVG9wIiwiYm9yZGVyTGVmdCIsIm1hcmdpbiIsIkdlbmVyYXRlQ29kZSIsImNsYXNzZXMiLCJ1c2VTdGF0ZSIsInByb2ZpbGUiLCJzZXRQcm9maWxlIiwidXNlRWZmZWN0IiwiZ2V0VmVuZG9ycyIsImVycm9yIiwicmVzdWx0IiwiY29uc29sZSIsImxvZyIsImRhdGEiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJwcmltYXJ5TnVtYmVyIiwia2V5cyIsImxlbmd0aCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBT0E7QUFFQSxJQUFNQSxTQUFTLEdBQUdDLDJFQUFVLENBQUMsVUFBQ0MsS0FBRDtBQUFBLFNBQVk7QUFDdkNDLFFBQUksRUFBRTtBQUNKQyxtQkFBYSxFQUFFLEVBRFg7QUFFSkMsa0JBQVksRUFBRSxFQUZWO0FBR0pDLHFCQUFlLEVBQUVKLEtBQUssQ0FBQ0ssT0FBTixDQUFjQyxPQUFkLENBQXNCQztBQUhuQyxLQURpQztBQU12Q0MsYUFBUyxFQUFFO0FBQ1RDLGtCQUFZLEVBQUUsRUFETDtBQUVUQyxhQUFPLEVBQUUsRUFGQTtBQUdUTixxQkFBZSxFQUFFSixLQUFLLENBQUNLLE9BQU4sQ0FBY00sU0FBZCxDQUF3QkMsS0FIaEM7QUFJVEMsWUFBTSxFQUFFO0FBSkMsS0FONEI7QUFZdkNDLFdBQU8sRUFBRTtBQUNQQyxnQkFBVSxFQUFFLEVBREw7QUFFUEMsV0FBSyxFQUFFaEIsS0FBSyxDQUFDSyxPQUFOLENBQWNDLE9BQWQsQ0FBc0JNO0FBRnRCLEtBWjhCO0FBZ0J2Q0ssV0FBTyxFQUFFO0FBQ1BDLGNBQVEsRUFBRSxPQURIO0FBRVBDLGFBQU8sRUFBRSxNQUZGO0FBR1BDLG9CQUFjLEVBQUUsUUFIVDtBQUlQSixXQUFLLEVBQUVoQixLQUFLLENBQUNLLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQk07QUFKdEIsS0FoQjhCO0FBc0J2Q1MsVUFBTSxFQUFFO0FBQ05DLGVBQVMsRUFBRSxjQURMO0FBRU5QLGdCQUFVLEVBQUUsTUFGTjtBQUdOUSxpQkFBVyxFQUFFLEVBSFA7QUFJTm5CLHFCQUFlLEVBQUVKLEtBQUssQ0FBQ0ssT0FBTixDQUFjTSxTQUFkLENBQXdCSixJQUpuQztBQUtOUyxXQUFLLEVBQUVoQixLQUFLLENBQUNLLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQk07QUFMdkIsS0F0QitCO0FBNkJ2Q1ksY0FBVSxFQUFFO0FBQ1ZMLGFBQU8sRUFBRSxNQURDO0FBRVZDLG9CQUFjLEVBQUUsUUFGTjtBQUdWSyxpQkFBVyxFQUFFLFNBSEg7QUFJVmhCLGtCQUFZLEVBQUUsRUFKSjtBQUtWaUIsZUFBUyxFQUFFLENBTEQ7QUFNVkMsZ0JBQVUsRUFBRSxDQU5GO0FBT1ZqQixhQUFPLEVBQUUsQ0FQQztBQVFWRyxZQUFNLEVBQUUsR0FSRTtBQVNWZSxZQUFNLEVBQUUsRUFURTtBQVVWeEIscUJBQWUsRUFBRUosS0FBSyxDQUFDSyxPQUFOLENBQWNNLFNBQWQsQ0FBd0JKO0FBVi9CO0FBN0IyQixHQUFaO0FBQUEsQ0FBRCxDQUE1QjtBQTJDZSxTQUFTc0IsWUFBVCxHQUF3QjtBQUFBOztBQUFBOztBQUNyQyxNQUFNQyxPQUFPLEdBQUdoQyxTQUFTLEVBQXpCOztBQURxQyxrQkFFUGlDLHNEQUFRLENBQUMsSUFBRCxDQUZEO0FBQUEsTUFFOUJDLE9BRjhCO0FBQUEsTUFFckJDLFVBRnFCOztBQUdyQ0MseURBQVMsZ1FBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQ0ZDLGtFQUFVLENBQUMsVUFBQ0MsS0FBRCxFQUFRQyxNQUFSLEVBQW1CO0FBQ2xDLGtCQUFJRCxLQUFKLEVBQVc7QUFDVEUsdUJBQU8sQ0FBQ0MsR0FBUixDQUFZSCxLQUFaO0FBQ0QsZUFGRCxNQUVPO0FBQ0xILDBCQUFVLENBQUNJLE1BQU0sQ0FBQ0csSUFBUixDQUFWO0FBQ0Q7QUFDRixhQU5lLENBRFI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsR0FBRCxJQVFOLEVBUk0sQ0FBVDtBQVVBLHNCQUNFO0FBQUssYUFBUyxFQUFFVixPQUFPLENBQUM3QixJQUF4QjtBQUFBLDJCQUNFLHFFQUFDLHNEQUFEO0FBQU0sZUFBUyxFQUFFNkIsT0FBTyxDQUFDdEIsU0FBekI7QUFBQSw2QkFHRSxxRUFBQyxzREFBRDtBQUFNLGlCQUFTLEVBQUVzQixPQUFPLENBQUNOLFVBQXpCO0FBQXFDLGlCQUFTLEVBQUUsQ0FBaEQ7QUFBQSxnQ0FDRSxxRUFBQyw2REFBRDtBQUFBLGlDQUNFLHFFQUFDLDREQUFEO0FBQVkscUJBQVMsRUFBRU0sT0FBTyxDQUFDYixPQUEvQjtBQUF3QyxtQkFBTyxFQUFDLElBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQU1FLHFFQUFDLDZEQUFEO0FBQWEsd0JBQWMsTUFBM0I7QUFBQSxrQ0FDRSxxRUFBQyw0REFBRDtBQUFZLHFCQUFTLEVBQUVhLE9BQU8sQ0FBQ2hCLE9BQS9CO0FBQXdDLG1CQUFPLEVBQUMsSUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFJRSxxRUFBQyw0REFBRDtBQUFZLHFCQUFTLEVBQUVnQixPQUFPLENBQUNULE1BQS9CO0FBQXVDLG1CQUFPLEVBQUMsSUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU5GLEVBY0dXLE9BQU8sSUFDTkEsT0FBTyxDQUFDUyxHQUFSLENBQVksVUFBQ0MsSUFBRCxFQUFPQyxLQUFQO0FBQUEsOEJBQ1YscUVBQUMsNkRBQUQ7QUFBYSwwQkFBYyxNQUEzQjtBQUFBLG9DQUNFLHFFQUFDLDREQUFEO0FBQ0UsdUJBQVMsRUFBRWIsT0FBTyxDQUFDaEIsT0FEckI7QUFFRSw0QkFBVyxXQUZiO0FBR0UscUJBQU8sRUFBQyxXQUhWO0FBQUEsd0JBS0c0QixJQUFJLENBQUNFO0FBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQVFFLHFFQUFDLDREQUFEO0FBQVksdUJBQVMsRUFBRWQsT0FBTyxDQUFDVCxNQUEvQjtBQUF1QyxxQkFBTyxFQUFDLFdBQS9DO0FBQUEsd0JBQ0dxQixJQUFJLENBQUNHLElBQUwsQ0FBVUM7QUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVJGO0FBQUEsYUFBaUNILEtBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRFU7QUFBQSxTQUFaLENBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXdDRDs7R0FyRHVCZCxZO1VBQ04vQixTOzs7S0FETStCLFkiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvYWRtaW4vdmVuZG9ycy5mMDI4MGZlNjc5NzNhMThiZmIyNy5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIjtcclxuaW1wb3J0IFNsaWRlIGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9TbGlkZVwiO1xyXG5pbXBvcnQge1xyXG4gIENhcmQsXHJcbiAgQ2FyZEFjdGlvbnMsXHJcbiAgQ2FyZENvbnRlbnQsXHJcbiAgR3JpZCxcclxuICBUeXBvZ3JhcGh5LFxyXG59IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZVwiO1xyXG5pbXBvcnQgeyBnZXRWZW5kb3JzIH0gZnJvbSBcIi4uLy4uL2FjdGlvbnMvdmVuZG9yXCI7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICByb290OiB7XHJcbiAgICBwYWRkaW5nQm90dG9tOiAyMCxcclxuICAgIHBhZGRpbmdSaWdodDogMjAsXHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLnBhbGV0dGUucHJpbWFyeS5tYWluLFxyXG4gIH0sXHJcbiAgY2FyZFN0eWxlOiB7XHJcbiAgICBib3JkZXJSYWRpdXM6IDIwLFxyXG4gICAgcGFkZGluZzogNDAsXHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLnBhbGV0dGUuc2Vjb25kYXJ5LmxpZ2h0LFxyXG4gICAgaGVpZ2h0OiA2NzUsXHJcbiAgfSxcclxuICBkZXRhaWxzOiB7XHJcbiAgICBtYXJnaW5MZWZ0OiAxMCxcclxuICAgIGNvbG9yOiB0aGVtZS5wYWxldHRlLnByaW1hcnkubGlnaHQsXHJcbiAgfSxcclxuICBoZWFkaW5nOiB7XHJcbiAgICBmb250U2l6ZTogXCIxLjVlbVwiLFxyXG4gICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcclxuICAgIGNvbG9yOiB0aGVtZS5wYWxldHRlLnByaW1hcnkubGlnaHQsXHJcbiAgfSxcclxuICBleHBhbmQ6IHtcclxuICAgIHRyYW5zZm9ybTogXCJyb3RhdGUoMGRlZylcIixcclxuICAgIG1hcmdpbkxlZnQ6IFwiYXV0b1wiLFxyXG4gICAgbWFyZ2luUmlnaHQ6IDEwLFxyXG4gICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5wYWxldHRlLnNlY29uZGFyeS5tYWluLFxyXG4gICAgY29sb3I6IHRoZW1lLnBhbGV0dGUucHJpbWFyeS5saWdodCxcclxuICB9LFxyXG4gIHRvdGFsQ29kZXM6IHtcclxuICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsXHJcbiAgICBib3JkZXJTdHlsZTogXCJvdXRzZXQgXCIsXHJcbiAgICBib3JkZXJSYWRpdXM6IDE1LFxyXG4gICAgYm9yZGVyVG9wOiAwLFxyXG4gICAgYm9yZGVyTGVmdDogMCxcclxuICAgIHBhZGRpbmc6IDUsXHJcbiAgICBoZWlnaHQ6IDYwMCxcclxuICAgIG1hcmdpbjogMjAsXHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLnBhbGV0dGUuc2Vjb25kYXJ5Lm1haW4sXHJcbiAgfSxcclxufSkpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gR2VuZXJhdGVDb2RlKCkge1xyXG4gIGNvbnN0IGNsYXNzZXMgPSB1c2VTdHlsZXMoKTtcclxuICBjb25zdCBbcHJvZmlsZSwgc2V0UHJvZmlsZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICB1c2VFZmZlY3QoYXN5bmMgKCkgPT4ge1xyXG4gICAgYXdhaXQgZ2V0VmVuZG9ycygoZXJyb3IsIHJlc3VsdCkgPT4ge1xyXG4gICAgICBpZiAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0UHJvZmlsZShyZXN1bHQuZGF0YSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPXtjbGFzc2VzLnJvb3R9PlxyXG4gICAgICA8Q2FyZCBjbGFzc05hbWU9e2NsYXNzZXMuY2FyZFN0eWxlfT5cclxuICAgICAgICB7LyogPEdyaWQgY29udGFpbmVyIHNwYWNpbmc9ezN9PlxyXG4gICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IHNtPXs2fT4gKi99XHJcbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPXtjbGFzc2VzLnRvdGFsQ29kZXN9IGVsZXZhdGlvbj17Mn0+XHJcbiAgICAgICAgICA8Q2FyZENvbnRlbnQ+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNsYXNzTmFtZT17Y2xhc3Nlcy5oZWFkaW5nfSB2YXJpYW50PVwiaDFcIj5cclxuICAgICAgICAgICAgICBWZW5kb3JzXHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgIDwvQ2FyZENvbnRlbnQ+XHJcbiAgICAgICAgICA8Q2FyZEFjdGlvbnMgZGlzYWJsZVNwYWNpbmc+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNsYXNzTmFtZT17Y2xhc3Nlcy5kZXRhaWxzfSB2YXJpYW50PVwiaDZcIj5cclxuICAgICAgICAgICAgICBOYW1lXHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgY2xhc3NOYW1lPXtjbGFzc2VzLmV4cGFuZH0gdmFyaWFudD1cImg2XCI+XHJcbiAgICAgICAgICAgICAgQ29kZXNcclxuICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgPC9DYXJkQWN0aW9ucz5cclxuICAgICAgICAgIHtwcm9maWxlICYmXHJcbiAgICAgICAgICAgIHByb2ZpbGUubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgIDxDYXJkQWN0aW9ucyBkaXNhYmxlU3BhY2luZyBrZXk9e2luZGV4fT5cclxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5kZXRhaWxzfVxyXG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwic2hvdyBtb3JlXCJcclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInN1YnRpdGxlMVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtpdGVtLnByaW1hcnlOdW1iZXJ9XHJcbiAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBjbGFzc05hbWU9e2NsYXNzZXMuZXhwYW5kfSB2YXJpYW50PVwic3VidGl0bGUxXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtpdGVtLmtleXMubGVuZ3RofVxyXG4gICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgIDwvQ2FyZEFjdGlvbnM+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvQ2FyZD5cclxuICAgICAgICB7LyogPC9HcmlkPlxyXG4gICAgICAgIDwvR3JpZD4gKi99XHJcbiAgICAgIDwvQ2FyZD5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ==