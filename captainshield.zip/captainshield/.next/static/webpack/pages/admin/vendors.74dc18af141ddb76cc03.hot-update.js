webpackHotUpdate_N_E("pages/admin/vendors",{

/***/ "./Components/admin/vendorList.js":
/*!****************************************!*\
  !*** ./Components/admin/vendorList.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return GenerateCode; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var D_KIB_captainshield_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/styles */ "./node_modules/@material-ui/core/esm/styles/index.js");
/* harmony import */ var _material_ui_core_Slide__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Slide */ "./node_modules/@material-ui/core/esm/Slide/index.js");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _actions_vendor__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../actions/vendor */ "./actions/vendor.js");
/* harmony import */ var _actions_vendor__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_actions_vendor__WEBPACK_IMPORTED_MODULE_7__);




var _jsxFileName = "D:\\KIB\\captainshield\\Components\\admin\\vendorList.js",
    _s = $RefreshSig$();






var useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__["makeStyles"])(function (theme) {
  return {
    root: {
      paddingBottom: 20,
      paddingRight: 20,
      backgroundColor: theme.palette.primary.main
    },
    cardStyle: {
      borderRadius: 20,
      padding: 40,
      backgroundColor: theme.palette.secondary.light,
      height: 675
    },
    details: {
      marginLeft: 10,
      color: theme.palette.primary.light
    },
    heading: {
      fontSize: "1.5em",
      display: "flex",
      justifyContent: "center",
      color: theme.palette.primary.light
    },
    expand: {
      transform: "rotate(0deg)",
      marginLeft: "auto",
      marginRight: 10,
      backgroundColor: theme.palette.secondary.main,
      color: theme.palette.primary.light
    },
    totalCodes: {
      borderStyle: "outset ",
      borderRadius: 15,
      borderTop: 0,
      borderLeft: 0,
      padding: 5,
      height: 600,
      width: 500,
      margin: 20,
      backgroundColor: theme.palette.secondary.main
    }
  };
});
function GenerateCode() {
  _s();

  var _this = this;

  var classes = useStyles();

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(null),
      profile = _useState[0],
      setProfile = _useState[1];

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])( /*#__PURE__*/Object(D_KIB_captainshield_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee() {
    return D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return Object(_actions_vendor__WEBPACK_IMPORTED_MODULE_7__["getVendors"])(function (error, result) {
              if (error) {
                console.log(error);
              } else {
                setProfile(result.data);
              }
            });

          case 2:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  })), []);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: classes.root,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Card"], {
      className: classes.cardStyle,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          display: "flex",
          justifyContent: "center"
        },
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Card"], {
          className: classes.totalCodes,
          elevation: 2,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["CardContent"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
              className: classes.heading,
              variant: "h1",
              children: "Vendors"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 81,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 80,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["CardActions"], {
            disableSpacing: true,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
              className: classes.expand,
              variant: "h6",
              children: "Name"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 86,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
              className: classes.details,
              variant: "h6",
              children: "Number"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 89,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
              className: classes.expand,
              variant: "h6",
              children: "Codes"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 92,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 85,
            columnNumber: 13
          }, this), profile && profile.map(function (item, index) {
            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["CardActions"], {
              disableSpacing: true,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
                className: classes.details,
                "aria-label": "show more",
                variant: "subtitle1",
                children: "".concat(item.firstName, " ").concat(item.lastName)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 99,
                columnNumber: 19
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
                className: classes.details,
                "aria-label": "show more",
                variant: "subtitle1",
                children: item.primaryNumber
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 106,
                columnNumber: 19
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
                className: classes.expand,
                variant: "subtitle1",
                children: item.keys.length
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 113,
                columnNumber: 19
              }, _this)]
            }, index, true, {
              fileName: _jsxFileName,
              lineNumber: 98,
              columnNumber: 17
            }, _this);
          })]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 79,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 70,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 69,
    columnNumber: 5
  }, this);
}

_s(GenerateCode, "MxkcOQ8VgTzKXCFgD7ayA1lKrDU=", false, function () {
  return [useStyles];
});

_c = GenerateCode;

var _c;

$RefreshReg$(_c, "GenerateCode");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vQ29tcG9uZW50cy9hZG1pbi92ZW5kb3JMaXN0LmpzIl0sIm5hbWVzIjpbInVzZVN0eWxlcyIsIm1ha2VTdHlsZXMiLCJ0aGVtZSIsInJvb3QiLCJwYWRkaW5nQm90dG9tIiwicGFkZGluZ1JpZ2h0IiwiYmFja2dyb3VuZENvbG9yIiwicGFsZXR0ZSIsInByaW1hcnkiLCJtYWluIiwiY2FyZFN0eWxlIiwiYm9yZGVyUmFkaXVzIiwicGFkZGluZyIsInNlY29uZGFyeSIsImxpZ2h0IiwiaGVpZ2h0IiwiZGV0YWlscyIsIm1hcmdpbkxlZnQiLCJjb2xvciIsImhlYWRpbmciLCJmb250U2l6ZSIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsImV4cGFuZCIsInRyYW5zZm9ybSIsIm1hcmdpblJpZ2h0IiwidG90YWxDb2RlcyIsImJvcmRlclN0eWxlIiwiYm9yZGVyVG9wIiwiYm9yZGVyTGVmdCIsIndpZHRoIiwibWFyZ2luIiwiR2VuZXJhdGVDb2RlIiwiY2xhc3NlcyIsInVzZVN0YXRlIiwicHJvZmlsZSIsInNldFByb2ZpbGUiLCJ1c2VFZmZlY3QiLCJnZXRWZW5kb3JzIiwiZXJyb3IiLCJyZXN1bHQiLCJjb25zb2xlIiwibG9nIiwiZGF0YSIsIm1hcCIsIml0ZW0iLCJpbmRleCIsImZpcnN0TmFtZSIsImxhc3ROYW1lIiwicHJpbWFyeU51bWJlciIsImtleXMiLCJsZW5ndGgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQU9BO0FBRUEsSUFBTUEsU0FBUyxHQUFHQywyRUFBVSxDQUFDLFVBQUNDLEtBQUQ7QUFBQSxTQUFZO0FBQ3ZDQyxRQUFJLEVBQUU7QUFDSkMsbUJBQWEsRUFBRSxFQURYO0FBRUpDLGtCQUFZLEVBQUUsRUFGVjtBQUdKQyxxQkFBZSxFQUFFSixLQUFLLENBQUNLLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQkM7QUFIbkMsS0FEaUM7QUFNdkNDLGFBQVMsRUFBRTtBQUNUQyxrQkFBWSxFQUFFLEVBREw7QUFFVEMsYUFBTyxFQUFFLEVBRkE7QUFHVE4scUJBQWUsRUFBRUosS0FBSyxDQUFDSyxPQUFOLENBQWNNLFNBQWQsQ0FBd0JDLEtBSGhDO0FBSVRDLFlBQU0sRUFBRTtBQUpDLEtBTjRCO0FBWXZDQyxXQUFPLEVBQUU7QUFDUEMsZ0JBQVUsRUFBRSxFQURMO0FBRVBDLFdBQUssRUFBRWhCLEtBQUssQ0FBQ0ssT0FBTixDQUFjQyxPQUFkLENBQXNCTTtBQUZ0QixLQVo4QjtBQWdCdkNLLFdBQU8sRUFBRTtBQUNQQyxjQUFRLEVBQUUsT0FESDtBQUVQQyxhQUFPLEVBQUUsTUFGRjtBQUdQQyxvQkFBYyxFQUFFLFFBSFQ7QUFJUEosV0FBSyxFQUFFaEIsS0FBSyxDQUFDSyxPQUFOLENBQWNDLE9BQWQsQ0FBc0JNO0FBSnRCLEtBaEI4QjtBQXNCdkNTLFVBQU0sRUFBRTtBQUNOQyxlQUFTLEVBQUUsY0FETDtBQUVOUCxnQkFBVSxFQUFFLE1BRk47QUFHTlEsaUJBQVcsRUFBRSxFQUhQO0FBSU5uQixxQkFBZSxFQUFFSixLQUFLLENBQUNLLE9BQU4sQ0FBY00sU0FBZCxDQUF3QkosSUFKbkM7QUFLTlMsV0FBSyxFQUFFaEIsS0FBSyxDQUFDSyxPQUFOLENBQWNDLE9BQWQsQ0FBc0JNO0FBTHZCLEtBdEIrQjtBQTZCdkNZLGNBQVUsRUFBRTtBQUNWQyxpQkFBVyxFQUFFLFNBREg7QUFFVmhCLGtCQUFZLEVBQUUsRUFGSjtBQUdWaUIsZUFBUyxFQUFFLENBSEQ7QUFJVkMsZ0JBQVUsRUFBRSxDQUpGO0FBS1ZqQixhQUFPLEVBQUUsQ0FMQztBQU1WRyxZQUFNLEVBQUUsR0FORTtBQU9WZSxXQUFLLEVBQUUsR0FQRztBQVFWQyxZQUFNLEVBQUUsRUFSRTtBQVNWekIscUJBQWUsRUFBRUosS0FBSyxDQUFDSyxPQUFOLENBQWNNLFNBQWQsQ0FBd0JKO0FBVC9CO0FBN0IyQixHQUFaO0FBQUEsQ0FBRCxDQUE1QjtBQTBDZSxTQUFTdUIsWUFBVCxHQUF3QjtBQUFBOztBQUFBOztBQUNyQyxNQUFNQyxPQUFPLEdBQUdqQyxTQUFTLEVBQXpCOztBQURxQyxrQkFFUGtDLHNEQUFRLENBQUMsSUFBRCxDQUZEO0FBQUEsTUFFOUJDLE9BRjhCO0FBQUEsTUFFckJDLFVBRnFCOztBQUdyQ0MseURBQVMsZ1FBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQ0ZDLGtFQUFVLENBQUMsVUFBQ0MsS0FBRCxFQUFRQyxNQUFSLEVBQW1CO0FBQ2xDLGtCQUFJRCxLQUFKLEVBQVc7QUFDVEUsdUJBQU8sQ0FBQ0MsR0FBUixDQUFZSCxLQUFaO0FBQ0QsZUFGRCxNQUVPO0FBQ0xILDBCQUFVLENBQUNJLE1BQU0sQ0FBQ0csSUFBUixDQUFWO0FBQ0Q7QUFDRixhQU5lLENBRFI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsR0FBRCxJQVFOLEVBUk0sQ0FBVDtBQVVBLHNCQUNFO0FBQUssYUFBUyxFQUFFVixPQUFPLENBQUM5QixJQUF4QjtBQUFBLDJCQUNFLHFFQUFDLHNEQUFEO0FBQU0sZUFBUyxFQUFFOEIsT0FBTyxDQUFDdkIsU0FBekI7QUFBQSw2QkFHRTtBQUNFLGFBQUssRUFBRTtBQUNMVyxpQkFBTyxFQUFFLE1BREo7QUFFTEMsd0JBQWMsRUFBRTtBQUZYLFNBRFQ7QUFBQSwrQkFNRSxxRUFBQyxzREFBRDtBQUFNLG1CQUFTLEVBQUVXLE9BQU8sQ0FBQ1AsVUFBekI7QUFBcUMsbUJBQVMsRUFBRSxDQUFoRDtBQUFBLGtDQUNFLHFFQUFDLDZEQUFEO0FBQUEsbUNBQ0UscUVBQUMsNERBQUQ7QUFBWSx1QkFBUyxFQUFFTyxPQUFPLENBQUNkLE9BQS9CO0FBQXdDLHFCQUFPLEVBQUMsSUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBTUUscUVBQUMsNkRBQUQ7QUFBYSwwQkFBYyxNQUEzQjtBQUFBLG9DQUNFLHFFQUFDLDREQUFEO0FBQVksdUJBQVMsRUFBRWMsT0FBTyxDQUFDVixNQUEvQjtBQUF1QyxxQkFBTyxFQUFDLElBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBSUUscUVBQUMsNERBQUQ7QUFBWSx1QkFBUyxFQUFFVSxPQUFPLENBQUNqQixPQUEvQjtBQUF3QyxxQkFBTyxFQUFDLElBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUpGLGVBT0UscUVBQUMsNERBQUQ7QUFBWSx1QkFBUyxFQUFFaUIsT0FBTyxDQUFDVixNQUEvQjtBQUF1QyxxQkFBTyxFQUFDLElBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFORixFQWlCR1ksT0FBTyxJQUNOQSxPQUFPLENBQUNTLEdBQVIsQ0FBWSxVQUFDQyxJQUFELEVBQU9DLEtBQVA7QUFBQSxnQ0FDVixxRUFBQyw2REFBRDtBQUFhLDRCQUFjLE1BQTNCO0FBQUEsc0NBQ0UscUVBQUMsNERBQUQ7QUFDRSx5QkFBUyxFQUFFYixPQUFPLENBQUNqQixPQURyQjtBQUVFLDhCQUFXLFdBRmI7QUFHRSx1QkFBTyxFQUFDLFdBSFY7QUFBQSxvQ0FLTTZCLElBQUksQ0FBQ0UsU0FMWCxjQUt3QkYsSUFBSSxDQUFDRyxRQUw3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFRRSxxRUFBQyw0REFBRDtBQUNFLHlCQUFTLEVBQUVmLE9BQU8sQ0FBQ2pCLE9BRHJCO0FBRUUsOEJBQVcsV0FGYjtBQUdFLHVCQUFPLEVBQUMsV0FIVjtBQUFBLDBCQUtHNkIsSUFBSSxDQUFDSTtBQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUkYsZUFlRSxxRUFBQyw0REFBRDtBQUFZLHlCQUFTLEVBQUVoQixPQUFPLENBQUNWLE1BQS9CO0FBQXVDLHVCQUFPLEVBQUMsV0FBL0M7QUFBQSwwQkFDR3NCLElBQUksQ0FBQ0ssSUFBTCxDQUFVQztBQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZkY7QUFBQSxlQUFpQ0wsS0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFEVTtBQUFBLFdBQVosQ0FsQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUF5REQ7O0dBdEV1QmQsWTtVQUNOaEMsUzs7O0tBRE1nQyxZIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2FkbWluL3ZlbmRvcnMuNzRkYzE4YWYxNDFkZGI3NmNjMDMuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzXCI7XHJcbmltcG9ydCBTbGlkZSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvU2xpZGVcIjtcclxuaW1wb3J0IHtcclxuICBDYXJkLFxyXG4gIENhcmRBY3Rpb25zLFxyXG4gIENhcmRDb250ZW50LFxyXG4gIEdyaWQsXHJcbiAgVHlwb2dyYXBoeSxcclxufSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmVcIjtcclxuaW1wb3J0IHsgZ2V0VmVuZG9ycyB9IGZyb20gXCIuLi8uLi9hY3Rpb25zL3ZlbmRvclwiO1xyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gbWFrZVN0eWxlcygodGhlbWUpID0+ICh7XHJcbiAgcm9vdDoge1xyXG4gICAgcGFkZGluZ0JvdHRvbTogMjAsXHJcbiAgICBwYWRkaW5nUmlnaHQ6IDIwLFxyXG4gICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5wYWxldHRlLnByaW1hcnkubWFpbixcclxuICB9LFxyXG4gIGNhcmRTdHlsZToge1xyXG4gICAgYm9yZGVyUmFkaXVzOiAyMCxcclxuICAgIHBhZGRpbmc6IDQwLFxyXG4gICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5wYWxldHRlLnNlY29uZGFyeS5saWdodCxcclxuICAgIGhlaWdodDogNjc1LFxyXG4gIH0sXHJcbiAgZGV0YWlsczoge1xyXG4gICAgbWFyZ2luTGVmdDogMTAsXHJcbiAgICBjb2xvcjogdGhlbWUucGFsZXR0ZS5wcmltYXJ5LmxpZ2h0LFxyXG4gIH0sXHJcbiAgaGVhZGluZzoge1xyXG4gICAgZm9udFNpemU6IFwiMS41ZW1cIixcclxuICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsXHJcbiAgICBjb2xvcjogdGhlbWUucGFsZXR0ZS5wcmltYXJ5LmxpZ2h0LFxyXG4gIH0sXHJcbiAgZXhwYW5kOiB7XHJcbiAgICB0cmFuc2Zvcm06IFwicm90YXRlKDBkZWcpXCIsXHJcbiAgICBtYXJnaW5MZWZ0OiBcImF1dG9cIixcclxuICAgIG1hcmdpblJpZ2h0OiAxMCxcclxuICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUucGFsZXR0ZS5zZWNvbmRhcnkubWFpbixcclxuICAgIGNvbG9yOiB0aGVtZS5wYWxldHRlLnByaW1hcnkubGlnaHQsXHJcbiAgfSxcclxuICB0b3RhbENvZGVzOiB7XHJcbiAgICBib3JkZXJTdHlsZTogXCJvdXRzZXQgXCIsXHJcbiAgICBib3JkZXJSYWRpdXM6IDE1LFxyXG4gICAgYm9yZGVyVG9wOiAwLFxyXG4gICAgYm9yZGVyTGVmdDogMCxcclxuICAgIHBhZGRpbmc6IDUsXHJcbiAgICBoZWlnaHQ6IDYwMCxcclxuICAgIHdpZHRoOiA1MDAsXHJcbiAgICBtYXJnaW46IDIwLFxyXG4gICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5wYWxldHRlLnNlY29uZGFyeS5tYWluLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEdlbmVyYXRlQ29kZSgpIHtcclxuICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcbiAgY29uc3QgW3Byb2ZpbGUsIHNldFByb2ZpbGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgdXNlRWZmZWN0KGFzeW5jICgpID0+IHtcclxuICAgIGF3YWl0IGdldFZlbmRvcnMoKGVycm9yLCByZXN1bHQpID0+IHtcclxuICAgICAgaWYgKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldFByb2ZpbGUocmVzdWx0LmRhdGEpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy5yb290fT5cclxuICAgICAgPENhcmQgY2xhc3NOYW1lPXtjbGFzc2VzLmNhcmRTdHlsZX0+XHJcbiAgICAgICAgey8qIDxHcmlkIGNvbnRhaW5lciBzcGFjaW5nPXszfT5cclxuICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBzbT17Nn0+ICovfVxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPXtjbGFzc2VzLnRvdGFsQ29kZXN9IGVsZXZhdGlvbj17Mn0+XHJcbiAgICAgICAgICAgIDxDYXJkQ29udGVudD5cclxuICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBjbGFzc05hbWU9e2NsYXNzZXMuaGVhZGluZ30gdmFyaWFudD1cImgxXCI+XHJcbiAgICAgICAgICAgICAgICBWZW5kb3JzXHJcbiAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8L0NhcmRDb250ZW50PlxyXG4gICAgICAgICAgICA8Q2FyZEFjdGlvbnMgZGlzYWJsZVNwYWNpbmc+XHJcbiAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgY2xhc3NOYW1lPXtjbGFzc2VzLmV4cGFuZH0gdmFyaWFudD1cImg2XCI+XHJcbiAgICAgICAgICAgICAgICBOYW1lXHJcbiAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNsYXNzTmFtZT17Y2xhc3Nlcy5kZXRhaWxzfSB2YXJpYW50PVwiaDZcIj5cclxuICAgICAgICAgICAgICAgIE51bWJlclxyXG4gICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBjbGFzc05hbWU9e2NsYXNzZXMuZXhwYW5kfSB2YXJpYW50PVwiaDZcIj5cclxuICAgICAgICAgICAgICAgIENvZGVzXHJcbiAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8L0NhcmRBY3Rpb25zPlxyXG4gICAgICAgICAgICB7cHJvZmlsZSAmJlxyXG4gICAgICAgICAgICAgIHByb2ZpbGUubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPENhcmRBY3Rpb25zIGRpc2FibGVTcGFjaW5nIGtleT17aW5kZXh9PlxyXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5kZXRhaWxzfVxyXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJzaG93IG1vcmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzdWJ0aXRsZTFcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2Ake2l0ZW0uZmlyc3ROYW1lfSAke2l0ZW0ubGFzdE5hbWV9YH1cclxuICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5kZXRhaWxzfVxyXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJzaG93IG1vcmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzdWJ0aXRsZTFcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2l0ZW0ucHJpbWFyeU51bWJlcn1cclxuICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBjbGFzc05hbWU9e2NsYXNzZXMuZXhwYW5kfSB2YXJpYW50PVwic3VidGl0bGUxXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2l0ZW0ua2V5cy5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZEFjdGlvbnM+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgey8qIDwvR3JpZD5cclxuICAgICAgICA8L0dyaWQ+ICovfVxyXG4gICAgICA8L0NhcmQ+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=