webpackHotUpdate_N_E("pages/admin/vendors",{

/***/ "./Components/admin/vendorList.js":
/*!****************************************!*\
  !*** ./Components/admin/vendorList.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return GenerateCode; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var D_KIB_captainshield_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/styles */ "./node_modules/@material-ui/core/esm/styles/index.js");
/* harmony import */ var _material_ui_core_Slide__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Slide */ "./node_modules/@material-ui/core/esm/Slide/index.js");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _actions_vendor__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../actions/vendor */ "./actions/vendor.js");
/* harmony import */ var _actions_vendor__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_actions_vendor__WEBPACK_IMPORTED_MODULE_7__);




var _jsxFileName = "D:\\KIB\\captainshield\\Components\\admin\\vendorList.js",
    _s = $RefreshSig$();






var useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__["makeStyles"])(function (theme) {
  return {
    root: {
      paddingBottom: 20,
      paddingRight: 20,
      backgroundColor: theme.palette.primary.main
    },
    cardStyle: {
      borderRadius: 20,
      padding: 40,
      backgroundColor: theme.palette.secondary.light,
      height: 675
    },
    details: {
      marginLeft: 10,
      color: theme.palette.primary.light
    },
    heading: {
      fontSize: "1.5em",
      display: "flex",
      justifyContent: "center",
      color: theme.palette.primary.light
    },
    expand: {
      transform: "rotate(0deg)",
      marginLeft: "auto",
      marginRight: 10,
      backgroundColor: theme.palette.secondary.main,
      color: theme.palette.primary.light
    },
    totalCodes: {
      borderStyle: "outset ",
      borderRadius: 15,
      borderTop: 0,
      borderLeft: 0,
      padding: 5,
      height: 600,
      margin: 20,
      backgroundColor: theme.palette.secondary.main
    }
  };
});
function GenerateCode() {
  _s();

  var _this = this;

  var classes = useStyles();

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(null),
      profile = _useState[0],
      setProfile = _useState[1];

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])( /*#__PURE__*/Object(D_KIB_captainshield_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee() {
    return D_KIB_captainshield_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return Object(_actions_vendor__WEBPACK_IMPORTED_MODULE_7__["getVendors"])(function (error, result) {
              if (error) {
                console.log(error);
              } else {
                setProfile(result.data);
              }
            });

          case 2:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  })), []);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: classes.root,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Card"], {
      className: classes.cardStyle,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Grid"], {
        container: true,
        spacing: 3,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Grid"], {
          item: true,
          xs: 12,
          sm: 6,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Card"], {
            className: classes.totalCodes,
            elevation: 2,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["CardContent"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
                className: classes.heading,
                variant: "h1",
                children: "Vendors"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 74,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 73,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["CardActions"], {
              disableSpacing: true,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
                className: classes.details,
                variant: "h6",
                children: "Name"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 79,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
                className: classes.expand,
                variant: "h6",
                children: "Codes"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 82,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 78,
              columnNumber: 15
            }, this), profile && profile.map(function (item, index) {
              return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["CardActions"], {
                disableSpacing: true,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
                  className: classes.details,
                  "aria-label": "show more",
                  variant: "subtitle1",
                  children: item.primaryNumber
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 89,
                  columnNumber: 21
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_6__["Typography"], {
                  className: classes.expand,
                  variant: "subtitle1",
                  children: item.keys.length
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 96,
                  columnNumber: 21
                }, _this)]
              }, index, true, {
                fileName: _jsxFileName,
                lineNumber: 88,
                columnNumber: 19
              }, _this);
            })]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 72,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 71,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 70,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 69,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 68,
    columnNumber: 5
  }, this);
}

_s(GenerateCode, "MxkcOQ8VgTzKXCFgD7ayA1lKrDU=", false, function () {
  return [useStyles];
});

_c = GenerateCode;

var _c;

$RefreshReg$(_c, "GenerateCode");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vQ29tcG9uZW50cy9hZG1pbi92ZW5kb3JMaXN0LmpzIl0sIm5hbWVzIjpbInVzZVN0eWxlcyIsIm1ha2VTdHlsZXMiLCJ0aGVtZSIsInJvb3QiLCJwYWRkaW5nQm90dG9tIiwicGFkZGluZ1JpZ2h0IiwiYmFja2dyb3VuZENvbG9yIiwicGFsZXR0ZSIsInByaW1hcnkiLCJtYWluIiwiY2FyZFN0eWxlIiwiYm9yZGVyUmFkaXVzIiwicGFkZGluZyIsInNlY29uZGFyeSIsImxpZ2h0IiwiaGVpZ2h0IiwiZGV0YWlscyIsIm1hcmdpbkxlZnQiLCJjb2xvciIsImhlYWRpbmciLCJmb250U2l6ZSIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsImV4cGFuZCIsInRyYW5zZm9ybSIsIm1hcmdpblJpZ2h0IiwidG90YWxDb2RlcyIsImJvcmRlclN0eWxlIiwiYm9yZGVyVG9wIiwiYm9yZGVyTGVmdCIsIm1hcmdpbiIsIkdlbmVyYXRlQ29kZSIsImNsYXNzZXMiLCJ1c2VTdGF0ZSIsInByb2ZpbGUiLCJzZXRQcm9maWxlIiwidXNlRWZmZWN0IiwiZ2V0VmVuZG9ycyIsImVycm9yIiwicmVzdWx0IiwiY29uc29sZSIsImxvZyIsImRhdGEiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJwcmltYXJ5TnVtYmVyIiwia2V5cyIsImxlbmd0aCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBT0E7QUFFQSxJQUFNQSxTQUFTLEdBQUdDLDJFQUFVLENBQUMsVUFBQ0MsS0FBRDtBQUFBLFNBQVk7QUFDdkNDLFFBQUksRUFBRTtBQUNKQyxtQkFBYSxFQUFFLEVBRFg7QUFFSkMsa0JBQVksRUFBRSxFQUZWO0FBR0pDLHFCQUFlLEVBQUVKLEtBQUssQ0FBQ0ssT0FBTixDQUFjQyxPQUFkLENBQXNCQztBQUhuQyxLQURpQztBQU12Q0MsYUFBUyxFQUFFO0FBQ1RDLGtCQUFZLEVBQUUsRUFETDtBQUVUQyxhQUFPLEVBQUUsRUFGQTtBQUdUTixxQkFBZSxFQUFFSixLQUFLLENBQUNLLE9BQU4sQ0FBY00sU0FBZCxDQUF3QkMsS0FIaEM7QUFJVEMsWUFBTSxFQUFFO0FBSkMsS0FONEI7QUFZdkNDLFdBQU8sRUFBRTtBQUNQQyxnQkFBVSxFQUFFLEVBREw7QUFFUEMsV0FBSyxFQUFFaEIsS0FBSyxDQUFDSyxPQUFOLENBQWNDLE9BQWQsQ0FBc0JNO0FBRnRCLEtBWjhCO0FBZ0J2Q0ssV0FBTyxFQUFFO0FBQ1BDLGNBQVEsRUFBRSxPQURIO0FBRVBDLGFBQU8sRUFBRSxNQUZGO0FBR1BDLG9CQUFjLEVBQUUsUUFIVDtBQUlQSixXQUFLLEVBQUVoQixLQUFLLENBQUNLLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQk07QUFKdEIsS0FoQjhCO0FBc0J2Q1MsVUFBTSxFQUFFO0FBQ05DLGVBQVMsRUFBRSxjQURMO0FBRU5QLGdCQUFVLEVBQUUsTUFGTjtBQUdOUSxpQkFBVyxFQUFFLEVBSFA7QUFJTm5CLHFCQUFlLEVBQUVKLEtBQUssQ0FBQ0ssT0FBTixDQUFjTSxTQUFkLENBQXdCSixJQUpuQztBQUtOUyxXQUFLLEVBQUVoQixLQUFLLENBQUNLLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQk07QUFMdkIsS0F0QitCO0FBNkJ2Q1ksY0FBVSxFQUFFO0FBQ1ZDLGlCQUFXLEVBQUUsU0FESDtBQUVWaEIsa0JBQVksRUFBRSxFQUZKO0FBR1ZpQixlQUFTLEVBQUUsQ0FIRDtBQUlWQyxnQkFBVSxFQUFFLENBSkY7QUFLVmpCLGFBQU8sRUFBRSxDQUxDO0FBTVZHLFlBQU0sRUFBRSxHQU5FO0FBT1ZlLFlBQU0sRUFBRSxFQVBFO0FBUVZ4QixxQkFBZSxFQUFFSixLQUFLLENBQUNLLE9BQU4sQ0FBY00sU0FBZCxDQUF3Qko7QUFSL0I7QUE3QjJCLEdBQVo7QUFBQSxDQUFELENBQTVCO0FBeUNlLFNBQVNzQixZQUFULEdBQXdCO0FBQUE7O0FBQUE7O0FBQ3JDLE1BQU1DLE9BQU8sR0FBR2hDLFNBQVMsRUFBekI7O0FBRHFDLGtCQUVQaUMsc0RBQVEsQ0FBQyxJQUFELENBRkQ7QUFBQSxNQUU5QkMsT0FGOEI7QUFBQSxNQUVyQkMsVUFGcUI7O0FBR3JDQyx5REFBUyxnUUFBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFDRkMsa0VBQVUsQ0FBQyxVQUFDQyxLQUFELEVBQVFDLE1BQVIsRUFBbUI7QUFDbEMsa0JBQUlELEtBQUosRUFBVztBQUNURSx1QkFBTyxDQUFDQyxHQUFSLENBQVlILEtBQVo7QUFDRCxlQUZELE1BRU87QUFDTEgsMEJBQVUsQ0FBQ0ksTUFBTSxDQUFDRyxJQUFSLENBQVY7QUFDRDtBQUNGLGFBTmUsQ0FEUjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHQUFELElBUU4sRUFSTSxDQUFUO0FBVUEsc0JBQ0U7QUFBSyxhQUFTLEVBQUVWLE9BQU8sQ0FBQzdCLElBQXhCO0FBQUEsMkJBQ0UscUVBQUMsc0RBQUQ7QUFBTSxlQUFTLEVBQUU2QixPQUFPLENBQUN0QixTQUF6QjtBQUFBLDZCQUNFLHFFQUFDLHNEQUFEO0FBQU0saUJBQVMsTUFBZjtBQUFnQixlQUFPLEVBQUUsQ0FBekI7QUFBQSwrQkFDRSxxRUFBQyxzREFBRDtBQUFNLGNBQUksTUFBVjtBQUFXLFlBQUUsRUFBRSxFQUFmO0FBQW1CLFlBQUUsRUFBRSxDQUF2QjtBQUFBLGlDQUNFLHFFQUFDLHNEQUFEO0FBQU0scUJBQVMsRUFBRXNCLE9BQU8sQ0FBQ04sVUFBekI7QUFBcUMscUJBQVMsRUFBRSxDQUFoRDtBQUFBLG9DQUNFLHFFQUFDLDZEQUFEO0FBQUEscUNBQ0UscUVBQUMsNERBQUQ7QUFBWSx5QkFBUyxFQUFFTSxPQUFPLENBQUNiLE9BQS9CO0FBQXdDLHVCQUFPLEVBQUMsSUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURGLGVBTUUscUVBQUMsNkRBQUQ7QUFBYSw0QkFBYyxNQUEzQjtBQUFBLHNDQUNFLHFFQUFDLDREQUFEO0FBQVkseUJBQVMsRUFBRWEsT0FBTyxDQUFDaEIsT0FBL0I7QUFBd0MsdUJBQU8sRUFBQyxJQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERixlQUlFLHFFQUFDLDREQUFEO0FBQVkseUJBQVMsRUFBRWdCLE9BQU8sQ0FBQ1QsTUFBL0I7QUFBdUMsdUJBQU8sRUFBQyxJQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTkYsRUFjR1csT0FBTyxJQUNOQSxPQUFPLENBQUNTLEdBQVIsQ0FBWSxVQUFDQyxJQUFELEVBQU9DLEtBQVA7QUFBQSxrQ0FDVixxRUFBQyw2REFBRDtBQUFhLDhCQUFjLE1BQTNCO0FBQUEsd0NBQ0UscUVBQUMsNERBQUQ7QUFDRSwyQkFBUyxFQUFFYixPQUFPLENBQUNoQixPQURyQjtBQUVFLGdDQUFXLFdBRmI7QUFHRSx5QkFBTyxFQUFDLFdBSFY7QUFBQSw0QkFLRzRCLElBQUksQ0FBQ0U7QUFMUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBUUUscUVBQUMsNERBQUQ7QUFBWSwyQkFBUyxFQUFFZCxPQUFPLENBQUNULE1BQS9CO0FBQXVDLHlCQUFPLEVBQUMsV0FBL0M7QUFBQSw0QkFDR3FCLElBQUksQ0FBQ0csSUFBTCxDQUFVQztBQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUkY7QUFBQSxpQkFBaUNILEtBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRFU7QUFBQSxhQUFaLENBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBd0NEOztHQXJEdUJkLFk7VUFDTi9CLFM7OztLQURNK0IsWSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9hZG1pbi92ZW5kb3JzLjQxNWIzMjRmMDZkOWZjMjE5YTkyLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlL3N0eWxlc1wiO1xyXG5pbXBvcnQgU2xpZGUgZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlL1NsaWRlXCI7XHJcbmltcG9ydCB7XHJcbiAgQ2FyZCxcclxuICBDYXJkQWN0aW9ucyxcclxuICBDYXJkQ29udGVudCxcclxuICBHcmlkLFxyXG4gIFR5cG9ncmFwaHksXHJcbn0gZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlXCI7XHJcbmltcG9ydCB7IGdldFZlbmRvcnMgfSBmcm9tIFwiLi4vLi4vYWN0aW9ucy92ZW5kb3JcIjtcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gIHJvb3Q6IHtcclxuICAgIHBhZGRpbmdCb3R0b206IDIwLFxyXG4gICAgcGFkZGluZ1JpZ2h0OiAyMCxcclxuICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUucGFsZXR0ZS5wcmltYXJ5Lm1haW4sXHJcbiAgfSxcclxuICBjYXJkU3R5bGU6IHtcclxuICAgIGJvcmRlclJhZGl1czogMjAsXHJcbiAgICBwYWRkaW5nOiA0MCxcclxuICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUucGFsZXR0ZS5zZWNvbmRhcnkubGlnaHQsXHJcbiAgICBoZWlnaHQ6IDY3NSxcclxuICB9LFxyXG4gIGRldGFpbHM6IHtcclxuICAgIG1hcmdpbkxlZnQ6IDEwLFxyXG4gICAgY29sb3I6IHRoZW1lLnBhbGV0dGUucHJpbWFyeS5saWdodCxcclxuICB9LFxyXG4gIGhlYWRpbmc6IHtcclxuICAgIGZvbnRTaXplOiBcIjEuNWVtXCIsXHJcbiAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxyXG4gICAgY29sb3I6IHRoZW1lLnBhbGV0dGUucHJpbWFyeS5saWdodCxcclxuICB9LFxyXG4gIGV4cGFuZDoge1xyXG4gICAgdHJhbnNmb3JtOiBcInJvdGF0ZSgwZGVnKVwiLFxyXG4gICAgbWFyZ2luTGVmdDogXCJhdXRvXCIsXHJcbiAgICBtYXJnaW5SaWdodDogMTAsXHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLnBhbGV0dGUuc2Vjb25kYXJ5Lm1haW4sXHJcbiAgICBjb2xvcjogdGhlbWUucGFsZXR0ZS5wcmltYXJ5LmxpZ2h0LFxyXG4gIH0sXHJcbiAgdG90YWxDb2Rlczoge1xyXG4gICAgYm9yZGVyU3R5bGU6IFwib3V0c2V0IFwiLFxyXG4gICAgYm9yZGVyUmFkaXVzOiAxNSxcclxuICAgIGJvcmRlclRvcDogMCxcclxuICAgIGJvcmRlckxlZnQ6IDAsXHJcbiAgICBwYWRkaW5nOiA1LFxyXG4gICAgaGVpZ2h0OiA2MDAsXHJcbiAgICBtYXJnaW46IDIwLFxyXG4gICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5wYWxldHRlLnNlY29uZGFyeS5tYWluLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEdlbmVyYXRlQ29kZSgpIHtcclxuICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcbiAgY29uc3QgW3Byb2ZpbGUsIHNldFByb2ZpbGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgdXNlRWZmZWN0KGFzeW5jICgpID0+IHtcclxuICAgIGF3YWl0IGdldFZlbmRvcnMoKGVycm9yLCByZXN1bHQpID0+IHtcclxuICAgICAgaWYgKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldFByb2ZpbGUocmVzdWx0LmRhdGEpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy5yb290fT5cclxuICAgICAgPENhcmQgY2xhc3NOYW1lPXtjbGFzc2VzLmNhcmRTdHlsZX0+XHJcbiAgICAgICAgPEdyaWQgY29udGFpbmVyIHNwYWNpbmc9ezN9PlxyXG4gICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IHNtPXs2fT5cclxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPXtjbGFzc2VzLnRvdGFsQ29kZXN9IGVsZXZhdGlvbj17Mn0+XHJcbiAgICAgICAgICAgICAgPENhcmRDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgY2xhc3NOYW1lPXtjbGFzc2VzLmhlYWRpbmd9IHZhcmlhbnQ9XCJoMVwiPlxyXG4gICAgICAgICAgICAgICAgICBWZW5kb3JzXHJcbiAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgPC9DYXJkQ29udGVudD5cclxuICAgICAgICAgICAgICA8Q2FyZEFjdGlvbnMgZGlzYWJsZVNwYWNpbmc+XHJcbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBjbGFzc05hbWU9e2NsYXNzZXMuZGV0YWlsc30gdmFyaWFudD1cImg2XCI+XHJcbiAgICAgICAgICAgICAgICAgIE5hbWVcclxuICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNsYXNzTmFtZT17Y2xhc3Nlcy5leHBhbmR9IHZhcmlhbnQ9XCJoNlwiPlxyXG4gICAgICAgICAgICAgICAgICBDb2Rlc1xyXG4gICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgIDwvQ2FyZEFjdGlvbnM+XHJcbiAgICAgICAgICAgICAge3Byb2ZpbGUgJiZcclxuICAgICAgICAgICAgICAgIHByb2ZpbGUubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8Q2FyZEFjdGlvbnMgZGlzYWJsZVNwYWNpbmcga2V5PXtpbmRleH0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5kZXRhaWxzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cInNob3cgbW9yZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwic3VidGl0bGUxXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5wcmltYXJ5TnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBjbGFzc05hbWU9e2NsYXNzZXMuZXhwYW5kfSB2YXJpYW50PVwic3VidGl0bGUxXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5rZXlzLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ2FyZEFjdGlvbnM+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDwvR3JpZD5cclxuICAgICAgPC9DYXJkPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9