module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("1TCz");


/***/ }),

/***/ "1TCz":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("KKbo");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("C9gN");
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("zPlV");
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_3__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const theme = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["createMuiTheme"])({
  palette: {
    primary: {
      main: "#1F1D1D",
      // Black ( Header )
      light: "#ffffff",
      background: "#9c0609",
      // Blue
      grey: "#edeff2" //Light Grey

    },
    secondary: {
      main: "#403D3D",
      // Dark Grey
      light: "#656565",
      // Green Color
      grey: "#403e3e",
      // darkGrey
      background: "#dfe4eb" //Light Grey

    }
  }
});

function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["NoSsr"], {
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["ThemeProvider"], {
      theme: theme,
      children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_auth__WEBPACK_IMPORTED_MODULE_2__[/* AuthProvider */ "a"], {
        children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(Component, _objectSpread({}, pageProps))
      })
    })
  });
}

/* harmony default export */ __webpack_exports__["default"] = (MyApp);

/***/ }),

/***/ "2kat":
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons");

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "4gBc":
/***/ (function(module, exports) {

module.exports = {
  regxFirstName: /^(?=.{1,50}$)[a-zA-Z]+(?:['_.\s][a-z]+)*$/,
  regxLastName: /^(?=.{1,50}$)[a-zA-Z]+(?:['_.\s][a-z]+)*$/,
  regxEmail: /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
  regxPrimaryNumber: /^\d{10}$/,
  regxSecondaryNumber: /^\d{10}$/,
  regxPassword: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/
};

/***/ }),

/***/ "6J8w":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _axios = _interopRequireDefault(__webpack_require__("zr5I"));

var _jsCookies = _interopRequireDefault(__webpack_require__("bmJ0"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = {
  getCodes: async (vendorId, cb) => {
    try {
      const res = await _axios.default.get(`${"https://captionshield.herokuapp.com/api"}/keys/vendor/remaining/${vendorId}`, {
        headers: {
          auth: _jsCookies.default.getItem("auth")
        }
      });

      if (res && res.status == 200) {
        cb(null, res.data.data);
      } else {
        cb(res.data.message, null);
      }
    } catch (error) {
      console.log(error);
    }
  },
  getProfile: async cb => {
    const res = await _axios.default.get(`${"https://captionshield.herokuapp.com/api"}/vendors/profile`, {
      headers: {
        auth: _jsCookies.default.getItem("auth")
      }
    });

    if (res && res.status == 200) {
      console.log(_jsCookies.default.getItem("auth"));
      cb(null, res.data);
    } else {
      console.log(res.data);
      cb(res.data.message, null);
    }
  },
  getVendors: async cb => {
    const res = await _axios.default.get(`${"https://captionshield.herokuapp.com/api"}/vendors`, {
      headers: {
        auth: _jsCookies.default.getItem("auth")
      }
    });

    if (res && res.status == 200) {
      console.log(_jsCookies.default.getItem("auth"));
      cb(null, res.data);
    } else {
      console.log(res.data);
      cb(res.data.message, null);
    }
  }
};

/***/ }),

/***/ "C9gN":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AuthProvider; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return useAuth; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return UserProtectedPage; });
/* unused harmony export AdminProtectedPage */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pages_vendor_login__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("iVr3");
/* harmony import */ var js_cookies__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("bmJ0");
/* harmony import */ var js_cookies__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(js_cookies__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _actions_vendor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("6J8w");
/* harmony import */ var _actions_vendor__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_actions_vendor__WEBPACK_IMPORTED_MODULE_4__);





const AuthContext = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["createContext"])({});
const AuthProvider = ({
  children
}) => {
  const {
    0: token,
    1: setToken
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const {
    0: vendor,
    1: setVendor
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const {
    0: admin,
    1: setAdmin
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(async () => {
    const userCookie = js_cookies__WEBPACK_IMPORTED_MODULE_3___default.a.getItem("auth");

    if (userCookie !== "" && userCookie != null) {
      if (userCookie) {
        setToken(userCookie);
        Object(_actions_vendor__WEBPACK_IMPORTED_MODULE_4__["getProfile"])((error, result) => {
          if (result.status) {
            if (result.data.isAdmin) {
              setAdmin(result.data);
            } else {
              setVendor(result.data);
            }
          }
        });
      }
    }
  }, []);

  const setVendorData = async data => {
    setVendor(data);
  };

  const setAdminData = async data => {
    setAdmin(data);
  };

  const setTokenData = token => {
    setToken(token);
  };

  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(AuthContext.Provider, {
    value: {
      isAuthenticatedUser: !!vendor,
      token,
      admin,
      vendor,
      setTokenData,
      setVendorData,
      setAdminData
    },
    children: children
  });
};
const useAuth = () => Object(react__WEBPACK_IMPORTED_MODULE_1__["useContext"])(AuthContext);
const UserProtectedPage = ({
  children
}) => {
  const {
    isAuthenticatedUser
  } = useAuth();

  if (!isAuthenticatedUser) {
    return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_pages_vendor_login__WEBPACK_IMPORTED_MODULE_2__["default"], {});
  } else {
    return children;
  }
};
const AdminProtectedPage = ({
  children
}) => {
  const {
    admin
  } = useAuth();

  if (!admin) {
    return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_pages_vendor_login__WEBPACK_IMPORTED_MODULE_2__["default"], {});
  } else {
    return children;
  }
};

/***/ }),

/***/ "F5FC":
/***/ (function(module, exports) {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "KKbo":
/***/ (function(module, exports) {

module.exports = require("@material-ui/core");

/***/ }),

/***/ "RnCP":
/***/ (function(module, exports) {

module.exports = require("@material-ui/lab");

/***/ }),

/***/ "bmJ0":
/***/ (function(module, exports) {

module.exports = require("js-cookies");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "iVr3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__("xnum");
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: external "@material-ui/core"
var core_ = __webpack_require__("KKbo");

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__("zr5I");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);

// EXTERNAL MODULE: ./regular-Expression.js
var regular_Expression = __webpack_require__("4gBc");

// EXTERNAL MODULE: external "js-cookies"
var external_js_cookies_ = __webpack_require__("bmJ0");
var external_js_cookies_default = /*#__PURE__*/__webpack_require__.n(external_js_cookies_);

// EXTERNAL MODULE: external "@material-ui/icons"
var icons_ = __webpack_require__("2kat");

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");

// EXTERNAL MODULE: ./auth.js
var auth = __webpack_require__("C9gN");

// EXTERNAL MODULE: external "@material-ui/lab"
var lab_ = __webpack_require__("RnCP");

// EXTERNAL MODULE: ./actions/vendor.js
var vendor = __webpack_require__("6J8w");

// CONCATENATED MODULE: ./Components/login.js












const useStyles = Object(core_["makeStyles"])(theme => ({
  root: {
    backgroundColor: theme.palette.primary.main
  },
  card: {
    marginTop: 150,
    marginBottom: 170,
    borderRadius: 20,
    padding: 30,
    backgroundColor: theme.palette.primary.light
  },
  btnStyle: {
    fontSize: "1.2em"
  },
  textStyle: {
    display: "flex",
    justifyContent: "center",
    textAlign: "center",
    padding: 20
  }
}));

function LogIn(props) {
  const classes = useStyles();
  const router = Object(router_["useRouter"])();
  const {
    0: open,
    1: setOpen
  } = Object(external_react_["useState"])(false);
  const {
    setAdminData,
    setVendorData,
    setTokenData
  } = Object(auth["c" /* useAuth */])();
  const {
    0: primaryNumber,
    1: setPrimaryNumber
  } = Object(external_react_["useState"])("");
  const {
    0: password,
    1: setPassword
  } = Object(external_react_["useState"])("");
  const {
    0: loginError,
    1: setLoginError
  } = Object(external_react_["useState"])(null);
  const {
    0: error,
    1: setError
  } = Object(external_react_["useState"])({
    primaryNumberErr: false,
    passwordErr: false
  });
  const {
    0: isPassVisible,
    1: setIsPassVisible
  } = Object(external_react_["useState"])(false);

  const handleChange = async () => {
    if (!(primaryNumber != "" && regular_Expression["regxPrimaryNumber"].test(primaryNumber))) {
      setError({
        primaryNumberErr: true
      });
    } else if (!(password != "" && regular_Expression["regxPassword"].test(password))) {
      setError({
        passwordErr: true
      });
    } else {
      login({
        primaryNumber: primaryNumber,
        password
      });
    }
  };

  const login = async ({
    primaryNumber,
    password
  }) => {
    setOpen(true);
    const userRes = await external_axios_default.a.post(`${"https://captionshield.herokuapp.com/api"}/vendors/login`, {
      primaryNumber: primaryNumber,
      password
    });
    const {
      user
    } = userRes.data.data;

    if (userRes != null) {
      external_js_cookies_default.a.setItem("auth", user.token, {
        expires: 7
      });
      setTokenData(user.token);
      Object(vendor["getProfile"])((error, result) => {
        if (result.status) {
          setOpen(false);

          if (user.isAdmin) {
            setAdminData(result.data.user);

            if (router.pathname === "/vendor/login") {
              router.replace("/admin/dashboard");
            }
          } else {
            setVendorData(result.data.user);

            if (router.pathname === "/vendor/login") {
              router.replace("/vendor/dashboard");
            }
          }
        } else {
          setOpen(false);
          setLoginError(error);
        }
      });
    } else {
      setOpen(false);
      setLoginError(userRes.data.message);
    }
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: classes.root,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["Grid"], {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
            style: {
              display: "flex",
              justifyContent: "center"
            },
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["Grid"], {
              item: true,
              xs: 12,
              sm: 7,
              elevation: 4,
              children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(core_["Card"], {
                elevation: 3,
                className: classes.card,
                elevation: 2,
                children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["Snackbar"], {
                  open: loginError ? true : false,
                  autoHideDuration: 6000,
                  anchorOrigin: {
                    vertical: "top",
                    horizontal: "center"
                  },
                  onClose: () => setLoginError(null),
                  children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(lab_["Alert"], {
                    severity: "error",
                    children: loginError && loginError
                  })
                }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["Typography"], {
                  style: {
                    textAlign: "center",
                    fontSize: "2.5em",
                    display: "flex",
                    marginTop: 20,
                    justifyContent: "center"
                  },
                  variant: "h1",
                  children: "Welcome back !"
                }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(core_["Grid"], {
                  container: true,
                  spacing: 2,
                  style: {
                    marginTop: 20
                  },
                  children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["Grid"], {
                    item: true,
                    xs: 12,
                    sm: 12,
                    style: {
                      display: "flex",
                      justifyContent: "center"
                    },
                    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["TextField"], {
                      id: "outlined-basic",
                      variant: "outlined",
                      label: "Phone No.",
                      onChange: event => {
                        setError({
                          primaryNumberErr: false
                        });
                        setPrimaryNumber(event.target.value);
                      },
                      error: error.primaryNumberErr,
                      helperText: error.primaryNumberErr ? "please enter valid Phone no." : "",
                      fullWidth: true,
                      placeholder: "Phone No."
                    })
                  }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["Grid"], {
                    item: true,
                    xs: 12,
                    sm: 12,
                    style: {
                      display: "flex",
                      justifyContent: "center"
                    },
                    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["TextField"], {
                      id: "password",
                      variant: "outlined",
                      required: true,
                      label: "Password",
                      InputProps: {
                        className: classes.input
                      },
                      onChange: event => {
                        setError({
                          passwordErr: false
                        });
                        setPassword(event.target.value);
                      },
                      error: error.passwordErr,
                      helperText: error.PasswordErr == true ? "please enter valid Password" : "",
                      fullWidth: true,
                      InputProps: {
                        endAdornment: /*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["InputAdornment"], {
                          position: "end",
                          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["IconButton"], {
                            "aria-label": "toggle password visibility",
                            onClick: () => {
                              isPassVisible ? setIsPassVisible(false) : setIsPassVisible(true);
                            },
                            children: isPassVisible ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(icons_["Visibility"], {
                              fontSize: "small"
                            }) : /*#__PURE__*/Object(jsx_runtime_["jsx"])(icons_["VisibilityOff"], {
                              fontSize: "small"
                            })
                          })
                        })
                      },
                      type: isPassVisible ? "text" : "password",
                      value: password,
                      placeholder: "Password"
                    })
                  }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["Grid"], {
                    item: true,
                    xs: 12,
                    sm: 12,
                    style: {
                      display: "flex",
                      justifyContent: "center"
                    },
                    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["Button"], {
                      variant: "contained",
                      color: "primary",
                      className: classes.btnStyle,
                      size: "medium",
                      fullWidth: true,
                      onClick: handleChange,
                      children: "Log in"
                    })
                  }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
                    onClick: () => router.push("/forgetPassword"),
                    style: {
                      fontWeight: "bold",
                      marginLeft: 10,
                      cursor: "pointer"
                    },
                    children: "Forgot your password?"
                  }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["Grid"], {
                    item: true,
                    xs: 12,
                    sm: 12,
                    style: {
                      display: "flex",
                      justifyContent: "center"
                    },
                    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(core_["Box"], {
                      display: "flex",
                      flexWrap: "wrap",
                      alignContent: "flex-start",
                      className: classes.textStyle,
                      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
                        onClick: () => router.push("/vendor/register"),
                        style: {
                          fontWeight: "bold",
                          cursor: "pointer"
                        },
                        children: "New Here ? Register !"
                      })
                    })
                  })]
                })]
              })
            })
          })
        })
      })
    })
  });
}

/* harmony default export */ var Components_login = (LogIn); //   else {
//     const data = { primaryNumber, password };
//     try {
//       const res = await axios.post(
//         `${process.env.BASE_URL}/vendors/login`,
//         data,
//         {
//           headers: {
//             "Access-Control-Allow-Origin": "*",
//             "Content-Type": "application/json",
//             withCredentials: true,
//           },
//         }
//       );
//       if (res && res.data.isAuth) {
//         //to save token in cookies
//         cookies.setItem("auth", res.data.token, { expires: 3 });
//         router.replace("/vendor/dashboard");
//       } else {
//         alert("Something went wrong");
//       }
//     } catch (error) {
//       console.log(error);
//     }
//   }
// };
// CONCATENATED MODULE: ./pages/vendor/login.js







function Login(props) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])(head_default.a, {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1.0"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("title", {
        children: "User Sign-in | Doorest"
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Components_login, {
        role: "user"
      })
    })]
  });
}

/* harmony default export */ var vendor_login = __webpack_exports__["default"] = (Login);

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "zPlV":
/***/ (function(module, exports) {



/***/ }),

/***/ "zr5I":
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ })

/******/ });